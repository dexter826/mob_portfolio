# Component Architecture

`@mob-signal/components` provides reusable React components for product interfaces. Components are organized by semantic responsibility rather than visual appearance.

## Model

| Level | Responsibility |
| --- | --- |
| Foundation | Tokens, theme variables, typography, spacing, sizing, motion, and utilities |
| Primitive | Small reusable UI elements with limited product meaning |
| Composite | Reusable interactions built from primitives or accessible headless behavior |
| Pattern | Product-level composition built from components |

Styling resolves through `Primitive → Semantic → Component → Variant / State`.

## Requirements

- Public APIs describe semantic intent through props such as `variant`, `size`, `tone`, and `state`.
- Raw palette values are not part of component APIs or component styling.
- Interactive components expose keyboard behavior, visible focus, disabled behavior, and accessible naming.
- Stateful components declare their applicable states in `registry.json`; unrelated states are not added only for symmetry.
- Selection and status are not communicated by color alone.
- Action, focus, selection, navigation, progress, status, and brand roles remain semantically independent.
- UI labels use readable interface typography; monospace is reserved for technical metadata and identifiers.
- Spatial motion provides reduced-motion behavior without hiding the resulting state.
- Exported components include a colocated Storybook story.
- Stateful behavior and regression-prone interaction include automated tests.
- Narrow-screen behavior is explicit for components that can exceed the viewport.

## Layout

| Component | Type | Responsibility |
| --- | --- | --- |
| `Stack` | Primitive | Vertical token-spaced composition |
| `Cluster` | Primitive | Horizontal or wrapping composition |
| `Grid` | Primitive | Grid-based composition |
| `Divider` | Primitive | Structural separation |
| `Surface` | Primitive | Default visual grouping surface |
| `PageShell` | Composite | Application page shell |
| `SplitPane` | Composite | Two-zone master/detail or editor/preview layout |

`PageShell` supports navigation, header, main content, and secondary content regions. `SplitPane` supports unequal pane ratios and deliberate narrow-screen collapse.

## Core Controls

| Component | Type | Responsibility |
| --- | --- | --- |
| `Button` | Primitive | Text or icon-supported application action |
| `IconButton` | Primitive | Icon-only action with accessible naming |
| `Link` | Primitive | Navigation or link-style action |
| `Badge` | Primitive | Compact semantic label or status |
| `Avatar` | Primitive | Person or entity representation |
| `Icon` | Primitive | Token-sized Lucide icon rendering and accessible labeling |
| `Kbd` | Primitive | Compact keyboard shortcut representation |

`Button` supports primary, secondary, ghost, and danger variants with compact, default, and large sizing. Loading preserves layout and exposes busy state. Text buttons use the shared UI-label role; technical metadata typography is not part of the default action contract. Icon-only actions use `IconButton`.

`Avatar` uses an image when available and a deterministic fallback otherwise.

## Forms

| Component | Type | Responsibility |
| --- | --- | --- |
| `Field` | Composite | Label, description, requirement, and validation wrapper |
| `Input` | Primitive | Single-line text input |
| `Textarea` | Primitive | Multiline text input |
| `Checkbox` | Primitive | Binary or multi-selection control |
| `RadioGroup` | Primitive | Grouped single selection |
| `Switch` | Primitive | Immediate binary setting |
| `Select` | Primitive | Single selection from a defined option set |
| `Combobox` | Composite | Searchable single selection |
| `SearchInput` | Composite | Search field with search and clear affordances |
| `DatePicker` | Primitive | Native date entry with shared control anatomy |
| `FileUpload` | Primitive | Native file selection with shared control anatomy |
| `MultiSelect` | Composite | Searchable selection of multiple options |
| `NumberInput` | Primitive | Numeric entry with tabular alignment |

`Field` owns label-control wiring for a single compatible child control. It generates a control identifier when one is not supplied, propagates required and invalid semantics, and connects descriptions and errors through accessible description references without requiring manual `htmlFor` coordination.

`Combobox` supports controlled selection, searchable options, disabled options, loading, empty results, error feedback, and accessible expanded state. Selection closes the option surface.

`SearchInput` uses native search semantics. A clear action appears only when a controlled value and clear handler are available.

## Navigation

| Component | Type | Responsibility |
| --- | --- | --- |
| `Tabs` | Primitive | Switch between peer views |
| `Breadcrumb` | Composite | Hierarchical location navigation |
| `Pagination` | Composite | Page navigation for lists and tables |
| `SidebarNav` | Composite | Primary application navigation |
| `CommandBar` | Composite | Search, filters, selection context, and local actions |
| `CommandPalette` | Composite | Keyboard-first searchable command surface |

`Tabs` keeps long tab lists inside their own horizontal overflow region on narrow screens.

`Pagination` supports controlled page state, previous and next actions, sibling page windows, gap markers, and current-page semantics.

`SidebarNav` supports links or button-driven navigation, optional icons and badges, disabled items, and active-page semantics.

## Data Display

| Component | Type | Responsibility |
| --- | --- | --- |
| `Table` | Primitive | Structural table elements |
| `List` | Primitive | Structured repeated content |
| `DataTable` | Composite | Product-grade tabular interaction |
| `KeyValue` | Composite | Compact metadata presentation |
| `MonoValue` | Primitive | Technical identifiers and values |
| `Progress` | Primitive | Determinate or indeterminate progress |
| `Card` | Composite | Strong semantic containment |

`Table` contains narrow-screen overflow within the table wrapper. Table headings use the shared UI-label role; technical monospace treatment remains opt-in for cells and metadata values.

`DataTable` requires an explicit accessible table name, supports an optional visible caption, typed columns, optional filtering, controlled sorting, controlled row selection, controlled pagination, loading, error, empty, optional sticky headers, and compact density. Sort behavior is enabled only when the column and consumer provide the required sort contract. Numeric columns may request tabular figures independently from monospace styling.

`TableCell` and `KeyValue` expose numeric alignment separately from technical monospace treatment. `MonoValue` retains tabular figures because identifiers and machine-oriented values commonly benefit from stable glyph widths.

`Card` is reserved for meaningful containment; ordinary grouping uses `Surface`.

## Feedback

| Component | Type | Responsibility |
| --- | --- | --- |
| `Alert` | Composite | Persistent contextual feedback |
| `Skeleton` | Primitive | Loading placeholder |
| `Toast` | Composite | Transient non-blocking feedback |
| `EmptyState` | Composite | Empty collection or section state |
| `ErrorState` | Composite | Recoverable section or page failure |
| `InlineMessage` | Composite | Compact local feedback |

`Toast` is provider-backed with bounded visible stacking, queued notifications, configurable auto-dismiss, pause on hover or focus, and manual dismissal. Critical blocking failures remain in persistent local UI rather than relying on transient notification alone.

## Overlay and Disclosure

| Component | Type | Responsibility |
| --- | --- | --- |
| `Dialog` | Composite | Blocking focused task or confirmation |
| `Tooltip` | Primitive | Supplementary explanation |
| `DropdownMenu` | Composite | Contextual action menu |
| `Sheet` | Composite | Edge-entering secondary workflow |
| `Popover` | Composite | Anchored non-modal surface |
| `Collapsible` | Primitive | Progressive disclosure |

`Tooltip` does not carry required information that is unavailable elsewhere.

`Sheet` supports right, left, and bottom placement with overlay, close control, and composable content regions.

## Patterns

| Pattern | Composition |
| --- | --- |
| `DataWorkspace` | `PageShell + CommandBar + DataTable + detail surface` |
| `MasterDetail` | `SplitPane + List/DataTable + detail surface` |
| `FormPage` | `PageShell + Field groups + actions` |
| `Settings` | Grouped settings sections with structural separation |
| `Authentication` | Focused sign-in or account-entry composition |

Patterns compose existing components and do not introduce independent visual primitives.

## API Conventions

### Naming

Components use PascalCase. Props describe semantic intent rather than palette or implementation detail.

### Composition

Complex interactions use composable subcomponents when composition provides a clearer API than a large configuration object.

```tsx
<Dialog>
  <DialogTrigger />
  <DialogContent>
    <DialogHeader />
    <DialogBody />
    <DialogFooter />
  </DialogContent>
</Dialog>
```

### State

Stateful components support controlled behavior when application state is coordinated externally. Accessible behavior from Radix UI and cmdk is preserved rather than reimplemented.

Applicable states are declared per component in `registry.json`. State completeness follows interaction meaning rather than a universal checklist; for example, buttons define action states while data surfaces define loading, error, empty, populated, sorting, and selection states. Storybook exposes meaningful visual states, and automated tests cover behavior or accessibility where state transitions can regress.

### Styling

Applications select semantic variants and states. `className` may extend contextual layout where exposed without bypassing tokenized visual roles or accessibility behavior.

Visual implementation follows shared family anatomy before component-specific styling:

- control anatomy for text entry and selection triggers
- action anatomy for buttons
- selection anatomy for toggles, navigation, tabs, and semantically selectable rows
- floating anatomy for menus, popovers, and tooltips
- overlay anatomy for dialogs and sheets
- feedback anatomy for alerts, toasts, and empty or error states
- data anatomy for tables, lists, and metadata

Shared anatomy resolves through component tokens and theme runtime classes. Component source adds only the behavior, sizing, or semantic treatment unique to that component. Activatable controls share pointer affordance, coarse-pointer target enhancement, and disabled cursor behavior. Generic structural content does not synthesize widget selection semantics. Decorative brand recipes stay outside core component anatomy. This keeps hover, focus, disabled, selected, invalid, elevation, geometry, motion, and typography-role rules consistent across a family.
