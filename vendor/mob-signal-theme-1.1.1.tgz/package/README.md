# Theme Runtime

`@mob-signal/theme` provides runtime CSS and font entrypoints for M.O.B Signal.

## Entrypoints

| Import | Content |
| --- | --- |
| `@mob-signal/theme/fonts.css` | Geist Variable and JetBrains Mono Variable font sources |
| `@mob-signal/theme/styles.css` | Complete stylesheet including Tailwind preflight and generated utilities |
| `@mob-signal/theme/runtime.css` | Tokens, shared styles, and brand recipes without Tailwind preflight or utilities |

```ts
import "@mob-signal/theme/fonts.css";
import "@mob-signal/theme/styles.css";
```

## Applications that compile Tailwind

Import `@mob-signal/theme/runtime.css` instead of `styles.css`. Register the installed component package as a Tailwind source so its utility classes are compiled by the application:

```css
@import "tailwindcss";
@import "@mob-signal/theme/runtime.css";

@source "../node_modules/@mob-signal/components/dist";
```

Add the patterns package to `@source` only when it is installed. Do not load both theme stylesheets.

When the application already loads Geist and JetBrains Mono, omit `fonts.css` and map `--ds-font-sans` and `--ds-font-mono` to the application font variables.

## Theme Selection

Dark theme is active by default. Light theme is selected on the document or application root:

```ts
document.documentElement.dataset.theme = "light";
```

Components continue to reference the same semantic roles; the active theme changes the resolved values.

## Runtime Layers

```text
Primitive tokens
      ↓
Semantic tokens
      ↓
Component tokens
      ↓
CSS custom properties
      ↓
Components and patterns
```

`packages/theme/src/tokens.css` is generated from token JSON. `packages/theme/src/index.css` contains the shared runtime source. `styles.css` adds Tailwind preflight and generated utilities, while `runtime.css` keeps those concerns with the consuming application. `packages/theme/src/fonts.css` contains font imports.

## Shared Runtime Anatomy

Theme component classes centralize recurring visual contracts for controls, floating surfaces, overlays, menu items, feedback surfaces, selectable rows, product titles, section titles, UI labels, metadata labels, and identifiers. Components inside the same family compose these shared classes instead of reimplementing hover, focus, invalid, selected, elevation, geometry, or typography-role rules independently.

## Semantic State Roles

Action, focus, selection, navigation, progress, status, and brand accent remain separate semantic roles even when a theme resolves several roles to the same visible color. Component code consumes the role that matches interaction meaning rather than borrowing a visually similar token.

## Expressive Brand Recipes

Theme utilities provide optional presentation grammar without adding effect-specific component APIs. Available treatments include editorial headings, signal labels, indexed labels, signal frames, technical grids, media scanlines, grayscale media reveal, signal links, signal glow, short distortion, signal pulse, typing cursors, and reveal motion. Core product components remain usable and recognizable without these recipes.

## Generation

```bash
npm run tokens:generate
npm run tokens:check
```

Token values are changed in `packages/tokens/src/` before runtime CSS is regenerated.
